package com.agl.product.adw8_new.service;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Get {

}
